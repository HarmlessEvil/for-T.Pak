#include "cg.hpp"

# include <cmath>

double *r8ge_mv(int m, int n, double a[], double x[])
{
	int i;
	int j;
	double *b;

	b = new double[m];

	for (i = 0; i < m; i++)
	{
		b[i] = 0.0;
		for (j = 0; j < n; j++)
		{
			b[i] = b[i] + a[i + j*m] * x[j];
		}
	}

	return b;
}

void r8ge_cg(int n, double a[], double b[], double x[])
{
	double alpha;
	double *ap;
	double beta;
	int i;
	int it;
	double *p;
	double pap;
	double pr;
	double *r;
	double rap;

	ap = r8ge_mv(n, n, a, x);

	r = new double[n];
	for (i = 0; i < n; i++)
	{
		r[i] = b[i] - ap[i];
	}

	p = new double[n];
	for (i = 0; i < n; i++)
	{
		p[i] = b[i] - ap[i];
	}

	for (it = 1; it <= n; it++)
	{
		delete[] ap;
		ap = r8ge_mv(n, n, a, p);
		pap = r8vec_dot_product(n, p, ap);
		pr = r8vec_dot_product(n, p, r);

		if (pap == 0.0)
		{
			delete[] ap;
			break;
		}

		alpha = pr / pap;
		for (i = 0; i < n; i++)
		{
			x[i] = x[i] + alpha * p[i];
		}
		for (i = 0; i < n; i++)
		{
			r[i] = r[i] - alpha * ap[i];
		}

		rap = r8vec_dot_product(n, r, ap);

		beta = -rap / pap;

		for (i = 0; i < n; i++)
		{
			p[i] = r[i] + beta * p[i];
		}
	}

	delete[] p;
	delete[] r;

	return;
}


double *r8ge_res(int m, int n, double a[], double x[], double b[])
{
	int i;
	double *r;

	r = r8ge_mv(m, n, a, x);
	for (i = 0; i < m; i++)
	{
		r[i] = b[i] - r[i];
	}

	return r;
}

double r8vec_norm(int n, double a[])
{
	int i;
	double v;

	v = 0.0;

	for (i = 0; i < n; i++)
	{
		v = v + a[i] * a[i];
	}
	v = sqrt(v);

	return v;
}


double r8vec_norm_affine(int n, double v0[], double v1[])
{
	int i;
	double value;

	value = 0.0;

	for (i = 0; i < n; i++)
	{
		value = value + (v1[i] - v0[i]) * (v1[i] - v0[i]);
	}
	value = sqrt(value);

	return value;
}

double r8vec_dot_product(int n, double a1[], double a2[])
{
	int i;
	double value;

	value = 0.0;
	for (i = 0; i < n; i++)
	{
		value = value + a1[i] * a2[i];
	}
	return value;
}