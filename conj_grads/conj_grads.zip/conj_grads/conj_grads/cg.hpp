#pragma once

void r8ge_cg(int n, double a[], double b[], double x[]);
double *r8ge_mv(int m, int n, double a[], double x[]);
double *r8ge_res(int m, int n, double a[], double x[], double b[]);

double r8vec_norm(int n, double a[]);
double r8vec_norm_affine(int n, double a[], double b[]);

double r8vec_dot_product(int n, double a1[], double a2[]);