//
// Created by Alexander on 06.10.2016.
//

#ifndef NM_DIVSUB_MATRIX_HPP
#define NM_DIVSUB_MATRIX_HPP

#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

class Matrix {
public:
	Matrix(unsigned n);
	Matrix() = default;
	~Matrix();

	vector<double>& operator[](int i);
	friend istream& operator>>(istream& is, Matrix& x);
	friend ostream& operator<<(ostream& os, Matrix& x);
	friend ifstream& operator>>(ifstream& is, Matrix& x);
	Matrix operator*(Matrix& x);
	vector<double> operator*(vector<double>& x);

	vector<double> quadratize();
	Matrix transpose();
	unsigned int size();
protected:
	vector<vector<double>> tab;
};

vector<double> solve(Matrix a);
double scalarMul(vector<double> a, vector<double> b);

#endif //NM_DIVSUB_MATRIX_HPP