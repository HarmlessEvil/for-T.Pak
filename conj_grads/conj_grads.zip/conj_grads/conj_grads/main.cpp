#include "includes/Matrix.h"
#include "cg.hpp"

int main() {
	vector<double> B;
	Matrix A(10);

	ifstream fin("input.txt");
	fin >> A;

	B = A.quadratize();
	Matrix A1 = A.transpose();

	int n = A.size() + 1;
	double* a = new double[n * n];
	double* x1 = new double[n];
	double* x2 = new double[n];

	n--;

	for (int i = 0; i < n * n; i++) {
		a[i] = A1[i / n][i % n];
	}
	for (int i = 0; i < n; i++)
	{
		x1[i] = 0;
		x2[i] = 1;
	}

	n++;

	double* b = r8ge_mv(n, n, a, x1);

	r8ge_cg(n, a, b, x2);

	double* r = r = r8ge_res(n, n, a, x2, b);
	double r_norm = r8vec_norm(n, r);
	double e_norm = r8vec_norm_affine(n, x1, x2);

	cout << "\n";
	cout << "  Number of variables N = " << n << "\n";
	cout << "  Norm of residual ||Ax-b|| = " << r_norm << "\n";
	cout << "  Norm of error ||x1-x2|| = " << e_norm << "\n";

	system("pause");
	return 0;
}